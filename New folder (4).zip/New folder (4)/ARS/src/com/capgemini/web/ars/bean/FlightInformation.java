package com.capgemini.web.ars.bean;

import java.sql.Date;

public class FlightInformation
{
	private int flightno ;
	private String airline ;
    private Airport depArp ;
    private Airport arrArp ;
    private Date dep_date ;
    private Date arr_date ;
    private String dep_time ;
    private String arr_time ; 
    private int FirstSeats ; 
    private double FirstSeatFare ; 
    private int BussSeats ; 
    private double BussSeatsFare ;
    
	public FlightInformation()
	{
		super();
	}

	public FlightInformation(int flightno, String airline, Airport depCity,
			Airport arrCity, Date dep_date, Date arr_date, String dep_time,
			String arr_time, int firstSeats, double firstSeatFare, int bussSeats,
			double bussSeatsFare) 
	{
		super();
		this.flightno = flightno;
		this.airline = airline;
		this.depArp = depCity;
		this.arrArp = arrCity;
		this.dep_date = dep_date;
		this.arr_date = arr_date;
		this.dep_time = dep_time;
		this.arr_time = arr_time;
		this.FirstSeats = firstSeats;
		this.FirstSeatFare = firstSeatFare;
		this.BussSeats = bussSeats;
		this.BussSeatsFare = bussSeatsFare;
	}

	public int getFlightno() {
		return flightno;
	}

	public void setFlightno(int flightno) {
		this.flightno = flightno;
	}

	public String getAirline() {
		return airline;
	}

	public void setAirline(String airline) {
		this.airline = airline;
	}

	public Airport getDepArp() {
		return depArp;
	}

	public void setDepArp(Airport depArp) {
		this.depArp = depArp;
	}

	public Airport getArrArp() {
		return arrArp;
	}

	public void setArrArp(Airport arrArp) {
		this.arrArp = arrArp;
	}

	public Date getDep_date() {
		return dep_date;
	}

	public void setDep_date(Date dep_date) {
		this.dep_date = dep_date;
	}

	public Date getArr_date() {
		return arr_date;
	}

	public void setArr_date(Date arr_date) {
		this.arr_date = arr_date;
	}

	public String getDep_time() {
		return dep_time;
	}

	public void setDep_time(String dep_time) {
		this.dep_time = dep_time;
	}

	public String getArr_time() {
		return arr_time;
	}

	public void setArr_time(String arr_time) {
		this.arr_time = arr_time;
	}

	public int getFirstSeats() {
		return FirstSeats;
	}

	public void setFirstSeats(int firstSeats) {
		FirstSeats = firstSeats;
	}

	public double getFirstSeatFare() {
		return FirstSeatFare;
	}

	public void setFirstSeatFare(double firstSeatFare) {
		FirstSeatFare = firstSeatFare;
	}

	public int getBussSeats() {
		return BussSeats;
	}

	public void setBussSeats(int bussSeats) {
		BussSeats = bussSeats;
	}

	public double getBussSeatsFare() {
		return BussSeatsFare;
	}

	public void setBussSeatsFare(double bussSeatsFare) {
		BussSeatsFare = bussSeatsFare;
	}

	@Override
	public String toString() {
		return "FlightInformation [flightno=" + flightno + ", airline="
				+ airline + ", depArp=" + depArp + ", arrArp=" + arrArp
				+ ", dep_date=" + dep_date + ", arr_date=" + arr_date
				+ ", dep_time=" + dep_time + ", arr_time=" + arr_time
				+ ", FirstSeats=" + FirstSeats + ", FirstSeatFare="
				+ FirstSeatFare + ", BussSeats=" + BussSeats
				+ ", BussSeatsFare=" + BussSeatsFare + "]";
	}


	
	 
}
