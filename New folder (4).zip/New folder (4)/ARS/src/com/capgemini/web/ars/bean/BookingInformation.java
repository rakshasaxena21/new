package com.capgemini.web.ars.bean;

public class BookingInformation 
{
   		 private int BookingId;
	     private String custEmail ; 
	     private int noOfChildren ;
         private int noOfAdult ; 
	     private String classType ; 
	     private double  totalFare ; 
	     private String seatNumber ;
	     private Airport srcArp ; 
         private Airport destArp ;
         private int flightNo;
         
         public BookingInformation() 
         {
     		super();
         }


		public BookingInformation(int bookingId, String custEmail, int noOfChildren,
				int noOfAdult,String classType, double totalFare, String seatNumber,
				Airport srcCity, Airport destCity , int flightNo) 
		{
			super();
			this.BookingId = bookingId;
			this.custEmail = custEmail;
			this.noOfChildren = noOfChildren;
			this.noOfAdult = noOfAdult;
			this.classType = classType;
			this.totalFare = totalFare;
			this.seatNumber = seatNumber;
			this.srcArp = srcCity;
			this.destArp = destCity;
			this.flightNo = flightNo;
		}


		public int getBookingId() {
			return BookingId;
		}


		public void setBookingId(int bookingId) {
			BookingId = bookingId;
		}


		public String getCustEmail() {
			return custEmail;
		}


		public void setCustEmail(String custEmail) {
			this.custEmail = custEmail;
		}


		public int getNoOfChildren() {
			return noOfChildren;
		}


		public void setNoOfChildren(int noOfChildren) {
			this.noOfChildren = noOfChildren;
		}


		public int getNoOfAdult() {
			return noOfAdult;
		}


		public void setNoOfAdult(int noOfAdult) {
			this.noOfAdult = noOfAdult;
		}


		public String getClassType() {
			return classType;
		}


		public void setClassType(String classType) {
			this.classType = classType;
		}


		public double getTotalFare() {
			return totalFare;
		}


		public void setTotalFare(double totalFare) {
			this.totalFare = totalFare;
		}


		public String getSeatNumber() {
			return seatNumber;
		}


		public void setSeatNumber(String seatNumber) {
			this.seatNumber = seatNumber;
		}


		public Airport getSrcArp() {
			return srcArp;
		}


		public void setSrcArp(Airport srcArp) {
			this.srcArp = srcArp;
		}


		public Airport getDestArp() {
			return destArp;
		}


		public void setDestArp(Airport destArp) {
			this.destArp = destArp;
		}


		public int getFlightNo() {
			return flightNo;
		}


		public void setFlightNo(int flightNo) {
			this.flightNo = flightNo;
		}



		
}
